//
//  ViewController.swift
//  iosPractice03
//
//  Created by 河岡 諒 on 2019/05/13.
//  Copyright © 2019 河岡 諒. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textViewForResult: UITextView!
    
    
    
    
    /*ここから下を作ってください*/
    func mainfunc() {
        let H = 20 // 縦
        let W = 10 // 横
        
        
        
    }
    /*ここまでを作ってください*/
    
    
    
    
    
    func myPrint(_ text : Any){
        print(text)
        textViewForResult.insertText(String(describing: text) + "\n")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        mainfunc()
    }


}

